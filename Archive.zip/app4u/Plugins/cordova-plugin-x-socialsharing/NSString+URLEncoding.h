#import <Foundation/Foundation.h>

@interface NSString (URLEncoding)
@property (readonly) NSString *URLEncodedString;
@end
